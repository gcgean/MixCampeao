## 1. Product Overview
Mix Campeão é um MVP de venda de acesso a conteúdo/relatórios por **segmento**, com pagamento **Pix** e liberação automática via **webhook**.
Você navega, compra um segmento uma única vez e passa a ver relatórios por seção com prévia Top 3.

## 2. Core Features

### 2.1 User Roles
| Papel | Método de cadastro/entrada | Permissões principais |
|------|-----------------------------|-----------------------|
| Visitante | Sem cadastro | Ver lista de segmentos e prévia Top 3 por seção |
| Usuário | Cadastro/Login por **email + senha** | Comprar segmento via Pix; acessar relatórios completos dos segmentos pagos |
| Admin | Conta marcada como admin | CRUD de catálogo (segmentos, seções, produtos e vínculos); importar CSV/XLSX com validação e modos insert/upsert/replace |

### 2.2 Feature Module
Nosso MVP consiste nas seguintes páginas:
1. **Página Inicial**: lista de segmentos, CTA de compra/entrar, acesso rápido às prévias.
2. **Página do Segmento**: checkout Pix, status do pagamento, acesso liberado, relatório por seções (Top 3 e completo).
3. **Entrar / Criar conta**: autenticação por **email + senha** e retorno para continuar compra/acesso.
4. **Meus Acessos**: listar segmentos comprados e abrir relatórios.
5. **Admin**: CRUD + importação CSV/XLSX com validação e modos.

### 2.3 Page Details
| Page Name | Module Name | Feature description |
|---|---|---|
| Página Inicial | Catálogo de segmentos | Listar segmentos (nome, preço, status “já comprado” se logado). |
| Página Inicial | Prévia por seção | Mostrar Top 3 por seção (somente prévia, sem detalhes completos). |
| Entrar / Criar conta | Email + senha | Autenticar com email e senha.
- Criar conta com email+senha (quando ainda não existir).
- Redirecionar para a última página (ex: segmento) após sucesso. |
| Página do Segmento | Checkout Pix | Iniciar compra (criar pedido), exibir QR/“copia e cola”, instruções e prazo. |
| Página do Segmento | Status + liberação | Atualizar status (pendente/pago); liberar acesso quando webhook confirmar pagamento. |
| Página do Segmento | Relatório por seção | Exibir seções; para não-compradores mostrar somente Top 3; para compradores mostrar conteúdo completo. |
| Meus Acessos | Biblioteca | Listar segmentos pagos; abrir página do segmento já liberado. |
| Admin | CRUD de catálogo | Criar/editar/desativar **segmentos**, **seções** e **produtos**; manter vínculos **segmento ↔ produto** (segment_products). |
| Admin | Importação CSV/XLSX | Enviar arquivo, validar (colunas/tipos/duplicidades), pré-visualizar alterações e aplicar modo **insert/upsert/replace** com relatório de erros. |

## 3. Core Process
**Fluxo do usuário:** você abre a Página Inicial, escolhe um segmento, entra/cria conta com **email + senha** (se necessário), inicia pagamento Pix e aguarda confirmação; após o webhook marcar como pago, o conteúdo completo do segmento é liberado. Você pode voltar depois em “Meus Acessos”.

**Fluxo do admin:** você acessa o Admin, mantém o catálogo (segmentos/seções/produtos/vínculos) via CRUD e pode importar em lote via CSV/XLSX escolhendo o modo (insert/upsert/replace) após validação.

```mermaid
graph TD
  A["Página Inicial"] --> B["Página do Segmento"]
  A --> C["Entrar / Criar conta"]
  C --> A
  B --> D["Pagamento Pix (pendente)"]
  D --> E["Webhook confirma pagamento"]
  E --> F["Acesso liberado (conteúdo completo)"]
  A --> G["Meus Acessos"]
  G --> B
  H["Admin"] --> I["CRUD (segmentos/seções/produtos/vínculos)"]
  H --> J["Importar CSV/XLSX (validar + aplicar modo)"]
```
