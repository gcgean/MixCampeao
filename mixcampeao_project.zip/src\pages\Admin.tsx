export { default } from './admin/AdminPage'
