## 1. Architecture design

```mermaid
graph TD
  A["Navegador"] --> B["Web App (React + Vite)"]
  B --> C["API (Express)"]
  C --> D["PostgreSQL"]
  C --> E["Provedor Pix (Webhook)"]
```

## 2. Technology Description
* Frontend: React@18 + Vite + Tailwind
* Backend: Express (Node.js) + TypeScript
* Database: PostgreSQL
* Auth: JWT (email + senha com hash)

## 3. Rotas (web)
| Rota | Descrição |
|---|---|
| / | Home com lista de segmentos + prévia Top 3 |
| /entrar | Login/Cadastro (email + senha) |
| /segmentos/:slug | Prévia, checkout Pix, status e relatório completo |
| /meus-acessos | Segmentos comprados |
| /admin | Admin (CRUD + importação) |

## 4. APIs (REST)
Padrão: JSON; erro no formato `{ "error": { "code", "message", "details?" } }`.

### 4.1 Auth
* `POST /api/auth/register` → `{ name, email, password }`
* `POST /api/auth/login` → `{ email, password }`
* `GET /api/auth/me` (Bearer) → usuário logado

### 4.2 Catálogo público
* `GET /api/segments` → lista segmentos ativos (+ flag `purchased` se logado)
* `GET /api/segments/:slug` → dados do segmento + prévia Top 3 por seção

### 4.3 Relatório
* `GET /api/segments/:slug/report` (Bearer) → relatório completo (requer compra paga)
* `GET /api/me/segments` (Bearer) → segmentos pagos do usuário

### 4.4 Pagamentos Pix
* `POST /api/payments/pix/create` (Bearer) → cria cobrança Pix do segmento
* `GET /api/payments/:id` (Bearer) → status do pagamento
* `POST /api/payments/pix/webhook` (assinatura) → confirma pagamento e libera acesso

### 4.5 Admin (RBAC: admin)
* `GET /api/admin/segments`
* `POST /api/admin/segments`
* `DELETE /api/admin/segments/:id`
* `GET /api/admin/segments/:segmentId/sections`
* `POST /api/admin/sections`
* `GET /api/admin/products`
* `POST /api/admin/products`
* `GET /api/admin/segment-products?segmentId=...`
* `POST /api/admin/segment-products`
* `DELETE /api/admin/segment-products/:id`
* `POST /api/admin/import` (multipart)
* `GET /api/admin/import`
* `GET /api/admin/import/:id`

## 5. Server architecture diagram
```mermaid
graph TD
  A["Routes"] --> B["Middlewares (Auth/RBAC)"]
  B --> C["Services (Pix/Import/Relatório)"]
  C --> D["DB (pg Pool)"]
```

## 6. Data model
### 6.1 Data model definition
```mermaid
erDiagram
  SEGMENT ||--o{ SECTION : "has"
  SEGMENT ||--o{ SEGMENT_PRODUCT : "has"
  SECTION ||--o{ SEGMENT_PRODUCT : "groups"
  PRODUCT ||--o{ SEGMENT_PRODUCT : "links"
  USER ||--o{ PURCHASE : "buys"
  SEGMENT ||--o{ PURCHASE : "sold_as"
  USER ||--o{ IMPORT_JOB : "runs"

  USER {
    uuid id
    string name
    string email
    string password_hash
    string role
    string status
  }
  SEGMENT {
    uuid id
    string code
    string slug
    string name
    numeric price_pix
    boolean active
  }
  SECTION {
    uuid id
    uuid segment_id
    string name
    int sort_order
  }
  PRODUCT {
    uuid id
    string name
    string unit
  }
  SEGMENT_PRODUCT {
    uuid id
    uuid segment_id
    uuid section_id
    uuid product_id
    numeric qty_ideal
    numeric avg_price
    string note
  }
  PURCHASE {
    uuid id
    uuid user_id
    uuid segment_id
    string status
    numeric amount
    string txid
    timestamp paid_at
  }
  IMPORT_JOB {
    uuid id
    uuid user_id
    string file_name
    string mode
    string status
    int total_rows
  }
```

### 6.2 Constraints e índices (resumo)
* `segments.slug` UNIQUE; `segments.code` UNIQUE
* `products.name` UNIQUE (case-insensitive)
* `sections` UNIQUE (`segment_id`, `name`)
* `segment_products` UNIQUE (`segment_id`, `product_id`)
* `purchases.txid` UNIQUE
* Índices: `purchases(user_id)`, `purchases(segment_id)`, `segment_products(segment_id)`, `sections(segment_id)`
