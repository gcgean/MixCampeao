# Design de Páginas — MVP Mix Campeão (mobile-first)

## Global Styles (tokens)

* Layout: **mobile-first** com Flexbox (stack vertical por padrão) + CSS Grid apenas onde ajudar (ex: listagens). Em telas maiores, evolui para 2 colunas e grids mais densos.

* Breakpoints: Mobile (padrão) ≤767px, Tablet 768–1199px, Desktop ≥1200px.

* Cores: bg #0B1020, surface #111A33, texto #EAF0FF, muted #A8B3D6, primária #6D5EF6, sucesso #22C55E, erro #EF4444.

* Tipografia: Inter/Roboto; escala 14/16/20/24/32; títulos semibold; corpo regular.

* Botões: primário preenchido; secundário outline; hover com +8% brilho; disabled 40% opacidade.

* Links: sublinhado no hover; foco visível (outline 2px primária).

## Padrões de UI

* Cabeçalho (fixo no topo): logo “Mix Campeão”, navegação (Segmentos, Meus Acessos), botão Entrar/Sair.

* Conteúdo em container responsivo (max 1120px); no mobile priorizar padding 16–20px e stack vertical; cards com radius 12 e sombra suave.

* Estados: skeleton para carregamento; banners para status de pagamento; empty states com CTA.

***

## 1) Página Inicial (/)

**Meta:** Title “Mix Campeão — Segmentos”, description “Compre por Pix e acesse relatórios por segmento”, OG básico (title/description).

**Estrutura:**

* Hero (mobile-first): stack vertical com texto + CTA; em telas maiores pode virar 2 colunas.

* Seção “Segmentos”: cards em 1 coluna no mobile; 2 colunas no tablet; 3 colunas no desktop.

* Seção “Prévia Top 3” (tabs ou acordeão por seção): mostra Top 3 (itens + métrica curta) e CTA “Abrir segmento”.

**Interações:**

* Se logado e já comprou: cards exibem “Acesso liberado” e CTA “Ver relatório”.

***

## 2) Entrar / Criar conta (/entrar)

**Meta:** Title “Entrar — Mix Campeão”.

**Estrutura (mobile-first):**

* Card/Sheet full-width no mobile (padding 16–20px) e card central (max 420px) no desktop.

* Form “Entrar”:

  * Campo email

  * Campo senha

  * Botão “Entrar”

* Ação secundária: link/botão “Criar conta” (alternar para formulário de cadastro com os mesmos campos).

**Interações:**

* Mostrar erros inline (email inválido, senha incorreta, etc.).

* Após autenticar, retornar para a última página visitada (ex: segmento).

***

## 3) Página do Segmento (/segmentos/:slug)

**Meta:** Title dinâmico “{Segmento} — Mix Campeão”; OG com nome do segmento.

**Estrutura (mobile-first):**

* Stack vertical no mobile: (1) info do segmento, (2) bloco de checkout Pix, (3) relatório por seções.

* No desktop, evolui para 2 colunas: checkout fixável (sticky) à esquerda e relatório à direita.

  * Checkout Pix: QR (imagem), botão “Copiar Pix”, timer/prazo, status (Pendente/Pago/Erro).

* “Relatório por Seções” (lista/accordeon).

  * Cada seção: header com título + chip “Prévia/Completo”.

  * Conteúdo prévia: Top 3 de **produtos** (nome + métrica curta) + CTA “Comprar para ver completo”.

  * Conteúdo completo (após liberação): render do full\_content com headings, tabelas simples e referência aos produtos vinculados ao segmento.

**Estados:**

* Não logado: banner “Entre para comprar/acessar”.

* Pagamento pendente: auto-refresh leve (polling) e callout explicando liberação via confirmação.

***

## 4) Meus Acessos (/meus-acessos)

**Meta:** Title “Meus Acessos — Mix Campeão”.

**Estrutura:**

* Lista em tabela (desktop) / cards (mobile) com: Segmento, status (Pago/Pendente), botão “Abrir”.

* Filtros rápidos: “Todos”, “Pagos”, “Pendentes”.

***

## 5) Admin (/admin)

**Meta:** Title “Admin — Mix Campeão”.

**Estrutura:** layout dashboard com sidebar (240px) + área principal.

* Sidebar: Segmentos, Seções, Produtos, Vínculos (Segmento ↔ Produto), Importação, Histórico.

* CRUD (padrão): tabela com busca; ações (Criar/Editar/Desativar); modal de formulário.

* Importação:

  * Upload CSV/XLSX + seletor de modo (insert/upsert/replace).

  * Validação: painel de “Erros” e “Avisos”, contadores e preview das linhas afetadas.

  * Botão “Aplicar importação” (exige confirmação) + relatório final (sucessos/falhas).

**Interações/Segurança:**

* Rotas admin exigem usuário com permissão; exibir tela “Acesso negado” se não-admin.
